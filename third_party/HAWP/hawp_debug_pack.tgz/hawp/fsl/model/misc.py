# hawp/fsl/model/misc.py
import torch
import torch.nn.functional as F

def non_maximum_suppression(a):
    ap = F.max_pool2d(a, 3, stride=1, padding=1)
    mask = (a == ap).float().clamp(min=0.0)
    return a * mask

def get_junctions(jloc, joff, topk=300, th=0.0, allow_fallback=True):
    """
    Robust get_junctions:
    - Auto-adjust threshold when jloc too weak
    - Never crash refinement due to empty detection
    """
    if jloc.dim() == 4:
        jloc = jloc.squeeze(0).squeeze(0)
    if joff.dim() == 4:
        joff = joff.squeeze(0)
    assert jloc.dim() == 2
    assert joff.dim() == 3 and joff.size(0) == 2

    H, W = jloc.size(-2), jloc.size(-1)
    jloc = torch.nan_to_num(jloc, nan=0.0)
    joff = torch.nan_to_num(joff, nan=0.0)

    K = min(int(topk), H * W)
    flat = jloc.reshape(-1)
    scores, idx = torch.topk(flat, K, largest=True, sorted=True)
    ys = (idx // W).to(torch.int64)
    xs = (idx %  W).to(torch.int64)

    dx = joff[0].reshape(-1)[idx]
    dy = joff[1].reshape(-1)[idx]
    xs_f = xs.to(jloc.dtype) + dx + 0.5
    ys_f = ys.to(jloc.dtype) + dy + 0.5

    inb = (xs_f >= 0.0) & (xs_f <= (W - 1.0)) & (ys_f >= 0.0) & (ys_f <= (H - 1.0))
    val = (scores > float(th)) & inb

    # --- fallback: no junction survived ---
    if not val.any():
        if allow_fallback:
            # 动态降低阈值，保留至少 1 个点
            fallback_K = min(4, K)
            scores, idx = torch.topk(flat, fallback_K, largest=True, sorted=True)
            ys = (idx // W).to(torch.int64)
            xs = (idx % W).to(torch.int64)
            xs_f = xs.to(jloc.dtype) + 0.5
            ys_f = ys.to(jloc.dtype) + 0.5
            junctions = torch.stack([xs_f, ys_f], dim=-1)
            print(f"[warn] get_junctions: all filtered, fallback to {fallback_K} pts")
            return junctions, scores
        else:
            empty_xy = jloc.new_zeros((0, 2))
            empty_sc = jloc.new_zeros((0,))
            return empty_xy, empty_sc

    xs_f = torch.clamp(xs_f[val], 0.0, W - 1.0 - 1e-3)
    ys_f = torch.clamp(ys_f[val], 0.0, H - 1.0 - 1e-3)
    scores = scores[val]
    junctions = torch.stack([xs_f, ys_f], dim=-1)
    return junctions, scores


# --------------------------------------------------
# Compatibility stub for visualization (plot_lines)
# --------------------------------------------------
import numpy as np
import cv2

def plot_lines(img, lines, color=(0, 255, 0), thickness=1):
    """
    Safe stub for visualization.
    Draws lines on the input image if OpenCV available.
    """
    if img is None or lines is None:
        return img
    out = img.copy()
    if isinstance(out, torch.Tensor):
        out = out.detach().cpu().numpy()
        out = (out * 255).astype(np.uint8)
        out = np.transpose(out, (1, 2, 0)) if out.ndim == 3 else out
    for l in lines:
        x1, y1, x2, y2 = map(int, l[:4])
        cv2.line(out, (x1, y1), (x2, y2), color, thickness)
    return out
