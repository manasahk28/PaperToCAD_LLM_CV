import torch
import numpy as np
import cv2
from torch.utils.data.dataloader import default_collate
from hawp.base import _C

class HAFMencoder(object):
    def __init__(self, cfg):
        self.dis_th = cfg.ENCODER.DIS_TH
        self.ang_th = cfg.ENCODER.ANG_TH
        self.num_static_pos_lines = cfg.ENCODER.NUM_STATIC_POS_LINES
        self.num_static_neg_lines = cfg.ENCODER.NUM_STATIC_NEG_LINES
        self.bck_weight = cfg.ENCODER.BACKGROUND_WEIGHT

    def __call__(self, annotations):
        targets, metas = [], []
        for ann in annotations:
            t, m = self._process_per_image(ann)
            targets.append(t)
            metas.append(m)
        return default_collate(targets), metas

    def adjacent_matrix(self, n, edges, device):
        mat = torch.zeros(n + 1, n + 1, dtype=torch.bool, device=device)
        if edges.size(0) > 0:
            mat[edges[:, 0], edges[:, 1]] = 1
            mat[edges[:, 1], edges[:, 0]] = 1
        return mat

    def _process_per_image(self, ann):
        """
        ⚙️ 优化版:
        - Junction 用 3x3 局部高斯热点代替单像素
        - 线段 lmap 用线宽=2 的粗线绘制
        其他逻辑保持一致
        """
        junctions = ann['junctions']
        device = junctions.device
        height, width = ann['height'], ann['width']

        jmap = np.zeros((height, width), dtype=np.float32)
        joff = np.zeros((2, height, width), dtype=np.float32)

        junctions[:, 0] = junctions[:, 0].clamp(min=0, max=width - 1e-3)
        junctions[:, 1] = junctions[:, 1].clamp(min=0, max=height - 1e-3)
        junctions_np = junctions.cpu().numpy()

        xint, yint = junctions_np[:, 0].astype(np.int32), junctions_np[:, 1].astype(np.int32)
        off_x = junctions_np[:, 0] - np.floor(junctions_np[:, 0]) - 0.5
        off_y = junctions_np[:, 1] - np.floor(junctions_np[:, 1]) - 0.5

        # --- 改进点 1：局部高斯热点 (3x3) ---
        for xi, yi in zip(xint, yint):
            if 1 <= xi < width - 1 and 1 <= yi < height - 1:
                jmap[yi - 1:yi + 2, xi - 1:xi + 2] = np.maximum(
                    jmap[yi - 1:yi + 2, xi - 1:xi + 2],
                    np.array([[0.25, 0.5, 0.25],
                              [0.5, 1.0, 0.5],
                              [0.25, 0.5, 0.25]], dtype=np.float32)
                )
        joff[0, yint, xint] = off_x
        joff[1, yint, xint] = off_y

        jmap = torch.from_numpy(jmap).to(device)
        joff = torch.from_numpy(joff).to(device)

        edges_positive = ann['edges_positive']
        edges_negative = ann['edges_negative']

        pos_mat = self.adjacent_matrix(junctions.size(0), edges_positive, device)
        neg_mat = self.adjacent_matrix(junctions.size(0), edges_negative, device)

        lines = torch.cat((junctions[edges_positive[:, 0]], junctions[edges_positive[:, 1]]), dim=-1)
        lines_neg = torch.cat(
            (junctions[edges_negative[:2000, 0]], junctions[edges_negative[:2000, 1]]), dim=-1)

        # --- 改进点 2：线宽 2 ---
        lmap = np.zeros((height, width), dtype=np.float32)
        lines_np = lines.cpu().numpy().astype(np.int32)
        for (x1, y1, x2, y2) in lines_np:
            cv2.line(lmap, (x1, y1), (x2, y2), 1, thickness=2)
        lmap = torch.from_numpy(lmap[None, ...]).to(device)

        # 以下部分保持原逻辑不动
        center_points = (lines[:, :2] + lines[:, 2:]) / 2.0
        cmap = torch.zeros((height, width), device=device)
        xx, yy = torch.meshgrid(torch.arange(width, dtype=torch.float32, device=device),
                                torch.arange(height, dtype=torch.float32, device=device),
                                indexing='xy')
        ctl_dis = torch.min(
            (xx[..., None] - center_points[None, None, :, 0]) ** 2 +
            (yy[..., None] - center_points[None, None, :, 1]) ** 2, dim=-1)[0]
        cmask = ctl_dis <= 4.0

        cxint, cyint = center_points[:, 0].long(), center_points[:, 1].long()
        cmap[cyint, cxint] = 1

        lpos = np.random.permutation(lines.cpu().numpy())[:self.num_static_pos_lines]
        lneg = np.random.permutation(lines_neg.cpu().numpy())[:self.num_static_neg_lines]
        lpos = torch.from_numpy(lpos).to(device)
        lneg = torch.from_numpy(lneg).to(device)
        lpre = torch.cat((lpos, lneg), dim=0)
        _swap = (torch.rand(lpre.size(0)) > 0.5).to(device)
        lpre[_swap] = lpre[_swap][:, [2, 3, 0, 1]]
        lpre_label = torch.cat([
            torch.ones(lpos.size(0), device=device),
            torch.zeros(lneg.size(0), device=device)
        ])

        meta = {
            'junc': junctions,
            'junctions': junctions,
            'Lpos': pos_mat,
            'Lneg': neg_mat,
            'lpre': lpre,
            'lpre_label': lpre_label,
            'lines': lines,
        }

        dismap = torch.sqrt(lmap[0] ** 2 + lmap[0] ** 2)[None]
        def _normalize(inp):
            mag = torch.sqrt(inp[0] * inp[0] + inp[1] * inp[1])
            return inp / (mag + 1e-6)

        hafm_dis = dismap.clamp(max=self.dis_th) / self.dis_th
        mask = torch.ones_like(hafm_dis) * self.bck_weight

        target = {
            'jloc': jmap[None],
            'joff': joff,
            'cloc': cmap[None],
            'dis': hafm_dis,
            'mask': mask
        }

        # ==========================================================
        # ✅ 兼容旧版 HAWP 接口 (md / dis / res)
        # ==========================================================
        target["md"] = target["cloc"].repeat(3, 1, 1)   # 模拟3通道方向图
        target["res"] = torch.zeros_like(target["dis"])  # 无残差项则设为零

        return target, meta

